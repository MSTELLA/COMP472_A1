# COMP472_A1
# Team Bean Burrito
Gabrielle Guidote 40175182  <br>
Marie-Jose Castellanos 40168044  <br>
Amrit Sohpal 40176197 
<br>
In order to run the files please place  the necessary datasets in the same folder as the runnable script. <br>
Specifically, make sure that both penguin.csv and abalone.csv datasets are present in the project folder. <br>
Additionally, both the COMP472_A1_AbaloneDataset.ipynb and COMP472_A1_PenguinDataset.ipynb have to be run.
